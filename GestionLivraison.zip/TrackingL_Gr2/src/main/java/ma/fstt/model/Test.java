package ma.fstt.model;

import java.sql.SQLException;
import java.util.List;

public class Test {

    public static void main(String[] args) {

// trait bloc try catch
        try {


            commandeDAO commandeDAO = new commandeDAO();
          //  Livreur liv = new Livreur(0l , "liv3" , "200000000");
commande cmd=new commande(0l,"prod1", "45","45");

commandeDAO.delete(cmd);

         //   Livreur liv2 = new Livreur(0l , "liv55" , "100000000");
           // livreurDAO.save(liv2);
//long id=3;

          //  livreurDAO.delete(liv2);


          List<commande> cmdlist =  commandeDAO.getAll();

            for (commande cmd1 :cmdlist) {

                System.out.println(cmd1.toString());

            }



        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }


}
