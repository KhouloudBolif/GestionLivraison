package ma.fstt.model;

public class commande {
    private Long id_cmd ;

    private String client ;

    private String date_fin ;
    private String date_debut ;

    public commande() {
    }

    public commande(Long id_cmd,String client,String datedebut,String datefin) {
        this.id_cmd = id_cmd;
        this.client=client;
        this.date_debut=datedebut;
        this.date_fin=datefin;
    }

    public Long getId_cmd() {
        return id_cmd;
    }

    public String getClient() {
        return client;
    }

    public String getDate_fin() {
        return date_fin;
    }

    public String getDate_debut() {
        return date_debut;
    }

    public void setDate_debut(String date_debut) {
        this.date_debut = date_debut;
    }

    public void setDate_fin(String date_fin) {
        this.date_fin = date_fin;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public void setId_cmd(Long id_cmd) {
        this.id_cmd = id_cmd;
    }

    @Override
    public String toString() {
        return "commande{" +
                "id_cmd=" + id_cmd +
                ", client='" + client + '\'' +
                ", date_fin='" + date_fin + '\'' +
                ", date_debut='" + date_debut + '\'' +
                '}';
    }
}

