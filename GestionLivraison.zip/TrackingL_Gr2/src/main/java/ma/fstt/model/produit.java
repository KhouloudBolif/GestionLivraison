package ma.fstt.model;

public class produit {
    private Long id_prod ;

    private String nom ;

    private String prix ;

    private String quantite;

    public produit() {
    }

    public produit(Long id_prod,String nom ,String prix,String quantite) {
        this.id_prod = id_prod;
        this.nom=nom;
        this.quantite=quantite;
        this.prix=prix;
    }

    public Long getId_prod() {
        return id_prod;
    }

    public String getNom() {
        return nom;
    }

    public String getPrix() {
        return prix;
    }

    public String getQuantite() {
        return quantite;
    }

    public void setQuantite(String quantite) {
        this.quantite = quantite;
    }

    public void setPrix(String prix) {
        this.prix = prix;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setId_prod(Long id_prod) {
        this.id_prod = id_prod;
    }

    @Override
    public String toString() {
        return "produit{" +
                "id_prod=" + id_prod +
                ", nom='" + nom + '\'' +
                ", prix='" + prix + '\'' +
                ", quantite='" + quantite + '\'' +
                '}';
    }
}
