package ma.fstt.model;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class produitDAO extends BaseDAO<produit>{
    public produitDAO() throws SQLException {

        super();
    }

    @Override
    public void save(produit object) throws SQLException {

        String request = "insert into produit (nom , prix,quantite) values (?,? , ?)";

        // mapping objet table

        this.preparedStatement = this.connection.prepareStatement(request);
        // mapping
        this.preparedStatement.setString(1 , object.getNom());

        this.preparedStatement.setString(2 , object.getPrix());

        this.preparedStatement.setString(3 , object.getQuantite());



        this.preparedStatement.execute();
    }

    @Override
    public void update(produit object) throws SQLException {

    }






    @Override
    public void delete(produit object) throws SQLException {
        String request = "DELETE FROM produit  Where nom='"+ object.getNom() +"'";
        executeModifyQuery(request);
    }



    @Override
    public List<produit> getAll()  throws SQLException {

        List<produit> mylist = new ArrayList<produit>();

        String request = "select * from produit ";

        this.statement = this.connection.createStatement();

        this.resultSet =   this.statement.executeQuery(request);

// parcours de la table
        while ( this.resultSet.next()){

// mapping table objet
            mylist.add(new produit(this.resultSet.getLong(1) ,
                    this.resultSet.getString(2) , this.resultSet.getString(3),this.resultSet.getString(4)));


        }


        return mylist;
    }

    @Override
    public produit getOne(Long id) throws SQLException {
        return null;
    }
    public void executeModifyQuery(String request){
        try {
            //  connection connection=ds.getConnection();
            connection.createStatement().execute(request);
            //  connection.close();
        }catch (Exception e){
            System.err.println(e.getMessage());
        }
    }

}


