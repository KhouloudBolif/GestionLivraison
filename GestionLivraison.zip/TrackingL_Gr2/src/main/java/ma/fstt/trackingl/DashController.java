package ma.fstt.trackingl;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.util.Objects;

public class DashController {


   @FXML
   private void jButtonClicked1(ActionEvent event) {
try{
      Parent rout = FXMLLoader.load(getClass().getResource("Cmd-view.fxml"));
      Scene scene = new Scene(rout,600,600);
       Stage stage =new Stage();
   stage.setTitle("Commande");
       stage.setScene(scene);
        stage.show();

   }catch (Exception e){
   e.printStackTrace();
   }
}
@FXML

   private void jButtonClicked2(ActionEvent event) {
      try{
         Parent rout = FXMLLoader.load(getClass().getResource("hello-view.fxml"));
         Scene scene = new Scene(rout,600,600);
         Stage stage =new Stage();
         stage.setTitle("Livreur");
         stage.setScene(scene);
         stage.show();

      }catch (Exception e){
         e.printStackTrace();
      }
   }

@FXML
   private void jButtonClicked3(ActionEvent event) {
      try{
         Parent rout = FXMLLoader.load(getClass().getResource("prod-view.fxml"));
         Scene scene = new Scene(rout,600,600);
         Stage stage =new Stage();
         stage.setTitle("Produits");
         stage.setScene(scene);
         stage.show();

      }catch (Exception e){
         e.printStackTrace();
      }
   }


}
