package ma.fstt.trackingl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import ma.fstt.model.Livreur;
import ma.fstt.model.LivreurDAO;
import ma.fstt.model.commande;
import ma.fstt.model.commandeDAO;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class CmdController implements Initializable {


    @FXML
    private TextField client;

    @FXML
    private TextField date_debut;
    @FXML
    private TextField date_fin;


    @FXML
    private TableView<commande> mytable;


    @FXML
    private TableColumn<commande, Long> col_id;

    @FXML
    private TableColumn<commande, String> col_client;

    @FXML
    private TableColumn<commande, String> col_date_debut;
    @FXML
    private TableColumn<commande, String> col_date_fin;

    @FXML
    protected void onSaveButtonClick() {

        // accees a la bdd

        try {
            commandeDAO commandeDAO = new commandeDAO();

            commande cmd = new commande(0l, client.getText(), date_debut.getText(), date_fin.getText());

            commandeDAO.save(cmd);


            UpdateTable();


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }

    @FXML
    protected void onDeleteButtonClick() throws SQLException {

        // accees a la bdd


        commandeDAO commandeDAO = new commandeDAO();

        commande cmd = new commande(0l, client.getText(),date_debut.getText(), date_fin.getText());

        commandeDAO.delete(cmd);


        UpdateTable();


    }

    public void UpdateTable() {
        col_id.setCellValueFactory(new PropertyValueFactory<commande, Long>("id_cmd"));
        col_client.setCellValueFactory(new PropertyValueFactory<commande, String>("client"));

        col_date_debut.setCellValueFactory(new PropertyValueFactory<commande, String>("date_debut"));
        col_date_fin.setCellValueFactory(new PropertyValueFactory<commande, String>("date_fin"));


        mytable.setItems(this.getDatacommande());
    }

    public static ObservableList<commande> getDatacommande() {

        commandeDAO commandeDAO = null;

        ObservableList<commande> listfx = FXCollections.observableArrayList();

        try {
            commandeDAO = new commandeDAO();
            for (commande ettemp : commandeDAO.getAll())
                listfx.add(ettemp);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return listfx;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UpdateTable();

    }
}