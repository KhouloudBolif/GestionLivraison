package ma.fstt.trackingl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import ma.fstt.model.Livreur;
import ma.fstt.model.LivreurDAO;
import ma.fstt.model.produit;
import ma.fstt.model.produitDAO;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ProdController implements Initializable {


    @FXML
    private TextField nom ;

    @FXML
    private TextField quantite ;
    @FXML
    private TextField prix ;


    @FXML
    private TableView<produit> mytable ;


    @FXML
    private TableColumn<produit ,Long> col_id ;

    @FXML
    private TableColumn <produit ,String> col_nom ;

    @FXML
    private TableColumn <produit , String> col_prix ;
    @FXML
    private TableColumn <produit ,String> col_quantite ;

    @FXML
    protected void onSaveButtonClick() {

        // accees a la bdd

        try {
            produitDAO produitDAO = new produitDAO();

            produit prod = new produit(0l , nom.getText() , prix.getText(),quantite.getText());

            produitDAO.save(prod);


            UpdateTable();




        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }
   @FXML
    protected void onDeleteButtonClick() throws SQLException {

        // accees a la bdd


        produitDAO produitDAO = new produitDAO();

        produit prod = new produit(0l , nom.getText() , prix.getText(),quantite.getText());

        produitDAO.delete(prod);


        UpdateTable();







    }
    public void UpdateTable(){
        col_id.setCellValueFactory(new PropertyValueFactory<produit,Long>("id_prod"));
        col_nom.setCellValueFactory(new PropertyValueFactory<produit,String>("nom"));

        col_prix.setCellValueFactory(new PropertyValueFactory<produit,String>("prix"));
        col_quantite.setCellValueFactory(new PropertyValueFactory<produit,String>("quantite"));


        mytable.setItems(this.getDataproduits());
    }

    public static ObservableList<produit> getDataproduits(){

        produitDAO produitDAO = null;

        ObservableList<produit> listfx = FXCollections.observableArrayList();

        try {
         produitDAO = new produitDAO();
            for (produit ettemp : produitDAO.getAll())
                listfx.add(ettemp);

        }catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return listfx ;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UpdateTable();

    }
}